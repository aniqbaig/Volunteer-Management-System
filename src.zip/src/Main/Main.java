package Main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import static javafx.application.Application.launch;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        try {
            // Print the URL to debug the resource path
            System.out.println(getClass().getResource("/Resources/SignInScreen.fxml"));

            Parent root = FXMLLoader.load(getClass().getResource("/Resources/SignInScreen.fxml"));
            Scene scene = new Scene(root);
            primaryStage.setTitle("");
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try {
            DatabaseConnector.setConnection();
            launch(args);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
